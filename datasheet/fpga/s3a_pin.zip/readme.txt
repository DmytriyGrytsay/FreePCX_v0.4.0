EXTENDED SPARTAN-3A FAMILY FPGA PINOUT INFORMATION
============================================================
Release Date:  10-JAN-2009, v1.3


This archive contains two types of files.

*  The /tables directory contains comma-delimited ASCII text
   CSV files for each package type.  These files can be viewed
   and sorted using a spreadsheet program, viewed using a
   text editor, or parsed with user-created scripts.  Each
   line in the file represents one pin on the package.

*  The /footprints directory contains Excel XLS spreadsheets
   that show a footprint or map for each package type.  
   These are the source files for the footprints found in 
   PDF format in Module 4 of the data sheets.


PINOUT TABLES
=============

The comma-delimited ASCII text files list pinout information 
for a specific part/package combination. Each line represents 
one pin on the package.

For a particular package, there may be multiple FPGAs available
in that package.  Each device has its own separate file.

Here is a brief description of the fields available on each
line.

    PIN
    --------
    The pin identifier for each pin on the package.  Sorting
    by PIN orders the pins sequentially on the VQ100/TQ144
    quad flat pack style packages.

    PIN_# (QFP packages only)
    --------
    The PIN_# is similar to PIN, except that PIN_# is an integer
    value instead of an alphabetic value.  Sorting by PIN_#
    orders the pins sequentially on the VQ100/TQ144
    quad flat pack style packages.

    ROW (BGA packages only)
    --------
    Sorting by ROW orders the pins alphabetically on 
    the ball grid array packages.  Sorting by ROW is 
    sufficient for the smaller BGA packages.  However, note
    that the larger BGA packages have ROW indices such as 
    "AA", "AB", etc.  An additional field, called ROW_#, is
    provided to aid sorting.

    ROW_# (FG484/676 packages only)
    ----------
    The ROW_# is similar to ROW, except that ROW_# is an 
    integer value instead of an alphabetic value to aid with
    sorting when the alphabetic values go beyond AA.

    COLUMN (BGA packages only)
    -----------
    COLUMN is an integer value indicating the column
    number of the pin on a BGA package.

    <part><package>
    ----------
    The pin name identifier for each pin on the package.

    BANK
    ----
    Sorting by Column 3 orders the pins by their associated I/O 
    bank.  The possible values for bank include integers
    between 0 and 3, "VCCAUX", "GND", and "N/A".  "N/A" indicates
    that the pin is not associated with a specific bank.

    TYPE
    -----------
    The TYPE field indicates the pin type for a particular
    package pin.  The listed type matches those described
    in Module 4 of the Spartan-3A DSP data sheet.

    DIFF_PAIR
    ----------
    DIFF_PAIR shows "TRUE" for pins that are part of a
    differential pair.


FOOTPRINT DIAGRAMS
==================

The footprint files are all Microsoft Excel compatible 
spreadsheet files presenting a common footprint for each
package type.  The FT256 has three files since the XC3S50A
pinout has different differential pair labels than the XC3S200A
and XC3S400A, and the XC3S700A and XC3S1400A have a unique pinout.
The files show the pins on the package as viewed from the top
(QFP packages) or through the top of the package (BGA packages).
Note the location of the pin 1 indicator on QFP packages.

Each pin is labeled and color coded according to Module 4 of
the data sheets.  No Connect (N.C.) pins are also indicated 
with special symbols.

Most footprints were saved as 50% to 75% of normal size so that 
the entire footprint is visible on the screen.  To change the 
magnification, select View --> Zoom from the Excel top menu, 
then select the desired magnification factor.

Excel may issue a warning when you open the file indicating
that the file may contain macros.  Select either "Disable
Macros" or "Enable Macros".  There are no longer any active
macros in the Excel files.


REVISION HISTORY:
================

v1.0 12/5/06: Initial release

v1.0.1 1/10/07: Updated XC3S50A FT256 pin R13 from L20PN_2 to L20P_2

v1.0.2 2/9/07: Updated XC3S50A TQ144 pins 24 and 25 from L9 to L09

v1.0.3 3/23/07: Updated XC3S50A TQ144 pin 128 from CGND to GND

v1.1 4/15/08: Added new package .CSV tables and .XLS footprints for:
              VQ100 (XC3S50A and XC3S200A)
              FT256 (XC3S700A and XC3S1400A)

v1.2 6/26/08: Added remaining .XLS footprints for:
              TQ144
              FT256 (XC3S50A)
              FT256 (XC3S200A and XC3S400A)
              FG320
              FG400
              FG484
              FG676

v1.2.1 11/10/08: Corrected font for diamonds in FG484 footprint Excel file

v1.3 1/10/09: Combined with Spartan-3A DSP platform.  Updated tables for
FG484 and FG676 to include ROW_# for easier sorting.  Updated footprints to
clarify that AWAKE is a dual-purpose pin.  Removed PDF files that are
available in the data sheet.  Corrected SUSPEND pin to be in bank VCCAUX.
Other minor updates to files.

Revision History for Spartan-3A DSP Files:

v1.0 04/02/07: Initial release

v1.1 05/22/07: 
Changes made as follows to CS484 pinout:
	D3, D4, U21, and V22 were changed from type I/O 
        to type INPUT pins.
	U12 added GCLK0, V12 changed to GCLK1, and Y12 
        had GCLK removed.
Changes made as follows to the CS484 footprint:
	U21 and V22 were changed from type I/O to type 
        INPUT pins.
Changes made as follows to XC3SD1800A FG676 pinout:
        E6, F9, G18, W18, Y8, AD23, were changed from type 
        VREF to type INPUT pins.
        Y19 was changed from type INPUT to type VREF pin.
Updated tables to include ROW_# for easier sorting.
Updated FG676 footprints to indicate all
pin differences between XC3SD1800A and XC3SD3400A.
Removed PDF files that are available in the data sheet.
Updated readme.txt.

v1.2 06/02/08:
Changes made as follows to CS484 pinout:
        AA14 changed from GCLK2 to GCLK3
        AB13 added GCLK2

