CAUTION: 
This Tactical Update is intended as a fast response for the following
customer issue only. The risk inherent in this fast response is that there
is not enough time or resources available for the full regression testing
that is done for the Service Pack Updates and there is a higher risk of
introducing new problems. It is recommended that customers always install
the latest Service Pack Update, but only install Tactical Updates when needed
to resolve specific issues. This Tactical Update may not be compatible with
other Tactical Updates made available by Xilinx.

DESCRIPTION:
Xilinx Answer #42778
http://www.xilinx.com/support/answers/42778.htm

13.2 EDK, AXI_IIC - ACKs are missed when using non-zero INERTIAL_DELAYs 

When using the XPS or AXI_IIC controller, ACKs are missed when SDA_INERTIAL_DELAY or SCL_INTERTIAL_DELAY settings are used.  How do I resolve this issue? 

This issue is caused by a unsynchronized signal in the inertial delay debouncer, potentially causing incorrect behavior.


This issue is planned to be fixed for AXI_IIC starting with EDK 13.3.


The PLB XPS_IIC core is currently not planned to be updated with the fixes. A patch is available, however:

ftp://ftp.xilinx.com/pub/applications/misc/ar42778.zip
To use the patch, download and extract to the project pcores/ folder, run Hardware->Clean Netlist, and restart XPS.


COMPATIBILITY:
This core should work with all EDK versions that contain xps_iic_v2_03_a.

Last Updated:
9/28/2011
