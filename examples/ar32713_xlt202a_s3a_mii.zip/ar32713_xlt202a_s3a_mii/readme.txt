Date: June 8, 2009

File Name: ar32713_xlt202a_s3a_mii.zip

Description: This archive has the instantiation of the XPS_LL_TEMAC core with the MII physical interface targeting a Spartan-3A device and the recommended UCF constraints. 

Platform: All

Installation/Use: 

s3a_soft_mii_mhs.txt - This file contains the instantiation of the XPS_LL_TEMAC core in the MHS. It should be used as a template to get a better idea of the ports that are required to use this physical interface. 

s3a_soft_mii_ucf.txt - This file contains the recommended constraints for the MII implementation of XPS_LL_TEMAC on Spartan-3A. Some constraints can change depending on the system architecture. These recommended constraints should be appended to the system UCF. 


Who to Contact if you have problems?

Web Support
http://support.xilinx.com

North American Support
(Mon-Fri 7am-5pm PST)
Hotline: 1-800-255-7778 
or (408) 879-5199 
Fax: (408) 879-4442
Webcase: http://www.xilinx.com/support/clearexpress/websupport.htm 
 
European Support
(Mon-Fri 8:00am-5:30pm GMT)
Email : eurosupport@xilinx.com 
Webcase: http://www.xilinx.com/support/clearexpress/websupport.htm
 
Japan Support
(Mon-Fri  9:00am - 5:30pm JST) 
Hotline: (81)3-6744-7800
Webcase: http://www.xilinx.co.jp/support/clearexpress/websupport.htm